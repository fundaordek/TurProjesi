-- --------------------------------------------------------
-- Sunucu:                       127.0.0.1
-- Sunucu sürümü:                10.3.13-MariaDB - mariadb.org binary distribution
-- Sunucu İşletim Sistemi:       Win64
-- HeidiSQL Sürüm:               9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- tursirket için veritabanı yapısı dökülüyor
CREATE DATABASE IF NOT EXISTS `tursirket` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tursirket`;

-- tablo yapısı dökülüyor tursirket.calisanlar
CREATE TABLE IF NOT EXISTS `calisanlar` (
  `calisan_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `calisan_adi` varchar(50) NOT NULL DEFAULT '0',
  `calisan_soyad` varchar(50) NOT NULL DEFAULT '0',
  `calisan_yas` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`calisan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- tursirket.calisanlar: ~3 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `calisanlar` DISABLE KEYS */;
INSERT INTO `calisanlar` (`calisan_id`, `calisan_adi`, `calisan_soyad`, `calisan_yas`) VALUES
	(1, 'umut', 'yasar', 21),
	(2, 'hasan', 'ert', 45),
	(3, 'funda', 'mngcc', 30);
/*!40000 ALTER TABLE `calisanlar` ENABLE KEYS */;

-- tablo yapısı dökülüyor tursirket.document
CREATE TABLE IF NOT EXISTS `document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `path` varchar(50) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- tursirket.document: ~0 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;

-- tablo yapısı dökülüyor tursirket.katilan
CREATE TABLE IF NOT EXISTS `katilan` (
  `musteri_id` int(10) unsigned NOT NULL,
  `tur_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`musteri_id`,`tur_id`),
  KEY `tur_id` (`tur_id`),
  CONSTRAINT `FK_katilan_musteri` FOREIGN KEY (`musteri_id`) REFERENCES `musteri` (`musteri_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_katilan_turlar` FOREIGN KEY (`tur_id`) REFERENCES `turlar` (`tur_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- tursirket.katilan: ~6 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `katilan` DISABLE KEYS */;
INSERT INTO `katilan` (`musteri_id`, `tur_id`) VALUES
	(4, 1),
	(5, 4),
	(6, 2),
	(12, 4),
	(13, 1);
/*!40000 ALTER TABLE `katilan` ENABLE KEYS */;

-- tablo yapısı dökülüyor tursirket.musteri
CREATE TABLE IF NOT EXISTS `musteri` (
  `musteri_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad` varchar(50) NOT NULL DEFAULT '0',
  `soyad` varchar(50) NOT NULL DEFAULT '0',
  `telno` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`musteri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- tursirket.musteri: ~5 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `musteri` DISABLE KEYS */;
INSERT INTO `musteri` (`musteri_id`, `ad`, `soyad`, `telno`) VALUES
	(4, 'funda', 'ordek', 55555),
	(5, 'umut', 'yasar', 456325),
	(6, 'hasan', 'ertp', 23165),
	(12, 'nuran', 'habip', 789),
	(13, 'aysel', 'kurgg', 555);
/*!40000 ALTER TABLE `musteri` ENABLE KEYS */;

-- tablo yapısı dökülüyor tursirket.sirket
CREATE TABLE IF NOT EXISTS `sirket` (
  `sirket_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sirket_ad` varchar(50) NOT NULL,
  `hakkimizda` text NOT NULL,
  `calisan_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sirket_id`),
  KEY `calisan_id` (`calisan_id`),
  CONSTRAINT `FK_tursirket_calisanlar` FOREIGN KEY (`calisan_id`) REFERENCES `calisanlar` (`calisan_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- tursirket.sirket: ~1 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `sirket` DISABLE KEYS */;
/*!40000 ALTER TABLE `sirket` ENABLE KEYS */;

-- tablo yapısı dökülüyor tursirket.subeler
CREATE TABLE IF NOT EXISTS `subeler` (
  `sube_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sube_il` varchar(50) NOT NULL DEFAULT '0',
  `sube_ilce` varchar(50) NOT NULL DEFAULT '0',
  `sube_isim` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sube_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- tursirket.subeler: ~0 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `subeler` DISABLE KEYS */;
INSERT INTO `subeler` (`sube_id`, `sube_il`, `sube_ilce`, `sube_isim`) VALUES
	(1, 'hatay', 'defne', 'mutlu');
/*!40000 ALTER TABLE `subeler` ENABLE KEYS */;

-- tablo yapısı dökülüyor tursirket.turlar
CREATE TABLE IF NOT EXISTS `turlar` (
  `tur_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tur_yeri` varchar(50) NOT NULL DEFAULT '0',
  `tur_fiyat` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- tursirket.turlar: ~8 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `turlar` DISABLE KEYS */;
INSERT INTO `turlar` (`tur_id`, `tur_yeri`, `tur_fiyat`) VALUES
	(1, 'hatay', 200),
	(2, 'istanbul', 500),
	(4, 'ankara', 300),
	(5, 'antalya', 200),
	(11, 'eskişehir', 800);
/*!40000 ALTER TABLE `turlar` ENABLE KEYS */;

-- tablo yapısı dökülüyor tursirket.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userTuru` varchar(50) NOT NULL,
  `c` tinyint(3) unsigned NOT NULL,
  `r` tinyint(3) unsigned NOT NULL,
  `u` tinyint(3) unsigned NOT NULL,
  `d` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- tursirket.user: ~2 rows (yaklaşık) tablosu için veriler indiriliyor
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `uname`, `password`, `userTuru`, `c`, `r`, `u`, `d`) VALUES
	(1, 'admin', 'admin', 'Admin', 1, 1, 1, 1),
	(2, 'funda', 'funda', 'Admin', 1, 1, 1, 1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
